import java.util.HashSet;

/** A class pertaining to the management of offers and assets in the database
 *
 */
public class Trades {
    HashSet<Asset> Assets = new HashSet<Asset>();


}
